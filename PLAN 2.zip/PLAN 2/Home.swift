//
//  Home.swift
//  PLAN
//
//  Created by Atheer Alharbi on 14/08/2023.
//

import SwiftUI

struct Home: View {
//    @Binding var Museum: [Artifact]
//    @Binding var startDate : Date
//    @Binding var endDate : Date
    var body: some View {
        
                        
                        TabView {
                
                            HomePage()
                                .tabItem {
                                    Label("Country", systemImage: "network")
                                }
                    
                            Schedule(Museum: .constant([]), startDate: .constant(Date()), endDate: .constant(Date()))
                                .tabItem {
                                    Label("Schedule", systemImage: "calendar.badge.plus")
                                    
                            
                                }
                            
                            
                        }    }
}

//struct Home_Previews: PreviewProvider {
//    static var previews: some View {
//        Home()
//    }
//}
