import SwiftUI

struct SplashScreen2: View {
   //to tell if splash is active or not
   @State private var isActive=false
   @State private var size = 0.5
   @State private var opacity = 0.5
   
   let gradient = Gradient(colors:[Color("Color1"),Color("Color2"),Color("Color3"),Color("Color4"),Color("Color5")])
   
   var body: some View {
       
       //go to the next page
       if isActive{
           // add the name of the page
           Home()
       }
       
       else{//place the rest of the code here
           
           VStack{
               Spacer()
               HStack{
                   Spacer()
                   
                   Image("SplashImage").resizable().frame(width: 213,height:213)
                  
                   //  Text("App Name")
                   //    .foregroundColor(Color.white).font(.system(size:24)).bold()
                   
                   
             
               //animation part
                   .scaleEffect(size)
                   .opacity(opacity)
                   .onAppear{
                       withAnimation(.easeIn(duration: 3)){
                           self.size = 5
                           self.opacity=2
                       }
                       
                   }
                   Spacer()
               }
              
         
                   .onAppear{
                       DispatchQueue.main.asyncAfter(deadline: .now()+2){
                           self.isActive = true
                       }
                   }
               
               
               Spacer()
           }
           .background(LinearGradient(gradient: gradient, startPoint: .bottomLeading, endPoint: .topTrailing)).edgesIgnoringSafeArea(.all)
           
           
           
       }
   }
   
   struct splash_Previews: PreviewProvider {
       static var previews: some View {
           SplashScreen2()
       }
   }
}
