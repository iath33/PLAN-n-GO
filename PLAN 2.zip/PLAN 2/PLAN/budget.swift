import SwiftUI

struct Budget: View{
    @Binding  var startDate : Date
    @Binding  var endDate : Date
    @Binding  var numericValue: String
    
    var body: some View{
        
        VStack{
            
            Text("What is your budget for \(numericValue)people💰?")
                .font(.custom("Helvetica", size: 20))
                .fontWeight(.bold)
                .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                .multilineTextAlignment(.leading)
             //   .padding(.trailing, 80)
            
                .padding(.bottom,30)
            
            
            
            NavigationLink {
                  Planner(startDate: $startDate, endDate: $endDate)
            } label: {
                Text("35,000 - 45,000 SAR")
                
                    .font(.custom("Helvetica", size: 25))
                    .fontWeight(.bold)
                    .padding(.top,-30)
                    .frame(width: 320, height: 130)
                    .background((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                    .background(Color.white)
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5),radius: 4, x:0, y:2)
                
                
            }
            
            Image(systemName: "arrow.right.circle.fill")
                .font(.system(size:29))
                .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                .padding(.leading,250)
                .padding(.top, -60)
            
            Button(action: {}
                   
                   , label: {Text("46,000 - 55,000 SAR")
                    .font(.custom("Helvetica", size: 25))
                    .fontWeight(.bold)
                    .padding(.top,-30)
                    .frame(width: 320, height: 120)
                    .background((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                    .background(Color.white)
                    .cornerRadius(20)
                .shadow(color: Color.black.opacity(0.5),radius: 4, x:0, y:2)}
                   
                   
            )
            
            
            Image(systemName: "arrow.right.circle.fill")
                .font(.system(size:28))
                .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                .padding(.leading,250)
                .padding(.top, -60)
            
            Button(action: {
                
                
            }, label: {
                Text("56,000 - 65,000 SAR")
                    .font(.custom("Helvetica", size: 25))
                    .fontWeight(.bold)
                    .padding(.top,-30)
                    .frame(width: 320, height: 120)
                    .background((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                    .background(Color.white)
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5),radius: 4, x:0, y:2)
            })
            
            
            Image(systemName: "arrow.right.circle.fill")
                .font(.system(size:28))
                .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                .padding(.leading,250)
                .padding(.top, -60)
            
            
            Button(action: {
                
                
            }, label: {
                Text("66,000 - 75,000 SAR")
                    .font(.custom("Helvetica", size: 25))
                    .fontWeight(.bold)
                    .padding(.top,-30)
                    .frame(width: 320, height: 120)
                    .background((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                    .background(Color.white)
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5),radius: 4, x:0, y:2)
            })
            
            
            
            Image(systemName: "arrow.right.circle.fill")
                .font(.system(size:28))
                .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                .padding(.leading,250)
                .padding(.top, -60)
            
        }
        
    }
    
}
