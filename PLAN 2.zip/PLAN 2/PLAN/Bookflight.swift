


//
//  Bookflight.swift
//  PLAN
//
//  Created by Farah N on 19/01/1445 AH.
//

import SwiftUI

struct Bookflight: View {
    @Binding  var startDate : Date
    @Binding  var endDate : Date
    var body: some View {
        ScrollView{
            VStack{
                Text("")
                .padding()
                Text("Book a flight✈️")
                    .font(.title)
                    .bold()
                    .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                    .padding(.trailing, 160)
                
                
                
                Rectangle()
                    .frame(width: 350, height: 150)
                    .foregroundColor((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                    .overlay(
                        Text("Qatar Airways")
                            .font(.title2)
                            .bold()
                            .padding(.bottom, 70)
                            .padding(.trailing, 160)
                            .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                            .padding()
                            .padding(.top, 19.0)
                        
                    )
                    .overlay(
                        Image("qatar")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .aspectRatio(contentMode: .fit)
                            .padding(.leading, 200)
                            .padding(.bottom, 40)
                            .onTapGesture{
                        if let url = URL(string: "https://www.qatarairways.com/en-sa/homepage.html")
                        {
                            UIApplication.shared.open(url)}}
                        
                        
                    )
                
                
                    .overlay(Text("From \(formatDate(startDate)) to \(formatDate(endDate))")
                        .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                        .padding(.top, 50)
                    )
                  
                
                Rectangle()
                    .frame(width: 350, height: 150)
                    .foregroundColor((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                    .overlay(
                        Text("Saudi Airlines")
                            .font(.title2)
                            .bold()
                            .padding(.bottom, 70)
                            .padding(.trailing, 160)
                            .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                            .padding()
                            .padding(.top, 19.0)
                    )
                    .overlay(
                        Image("saudi")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .aspectRatio(contentMode: .fit)
                            .padding(.leading, 200)
                            .padding(.bottom, 40)
                            .onTapGesture{
                        if let url = URL(string: "https://www.saudia.com/?cid=&gclid=Cj0KCQjwoeemBhCfARIsADR2QCu9vA0k_xK_37Bs37TEO-5uB4n78Sk4D7s4I5eR2VLgrRZMJaGQpk0aApu1EALw_wcB")
                        {
                            UIApplication.shared.open(url)}}
                        
                        
                    )
                    .padding()
                    .overlay(Text("From \(formatDate(startDate)) to \(formatDate(endDate))")
                        .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                        .padding(.top, 70)
                    )
                
                Rectangle()
                    .frame(width: 350, height: 150)
                    .foregroundColor((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                    .overlay(
                        Text("FlyNass")
                            .font(.title2)
                            .bold()
                            .padding(.bottom, 70)
                            .padding(.trailing, 220)
                            .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                            .padding()
                            .padding(.top, 19.0)
                    )
                    .overlay(
                        Image("FN.svg")
                            .resizable()
                            .frame(width: 100, height: 70)
                            .aspectRatio(contentMode: .fit)
                            .padding(.leading, 200)
                            .padding(.bottom,30)
                            .onTapGesture{
                        if let url = URL(string: "https://www.flynas.com/en")
                        {
                            UIApplication.shared.open(url)}}
                        
                        
                        
                        
                    )
                    .overlay(Text("From \(formatDate(startDate)) to \(formatDate(endDate))")
                        .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                        .padding(.top, 50)
                    )
                
                   
                Rectangle()
                    .frame(width: 350, height: 150)
                    .foregroundColor((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                    .overlay(
                        Text("Italy Airways")
                            .font(.title2)
                            .bold()
                            .padding(.bottom, 70)
                            .padding(.trailing, 160)
                            .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                            .padding()
                            .padding(.top, 19.0)
                    )
                    .overlay(
                        Image("ITA.svg")
                            .resizable()
                            .frame(width: 90, height: 90)
                            .aspectRatio(contentMode: .fit)
                            .padding(.leading, 200)
                            .padding(.bottom, 10)
                            .onTapGesture{
                        if let url = URL(string: "https://www.ita-airways.com/en_us")
                        {
                            UIApplication.shared.open(url)}}
                        
                        
                        
                        
                    )
                
                    .overlay(Text("From \(formatDate(startDate)) to \(formatDate(endDate))")
                        .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                        .padding(.top, 50)
                    )
                    .padding()
                
                
            }
            .onAppear{
                print(formatDate(startDate))
            }
        }
    }
}
public func formatDate(_ date: Date) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd MMM yyyy" // Custom date format
    
    let formattedDate = dateFormatter.string(from: date)

    return formattedDate
}
struct Bookflight_Previews: PreviewProvider {
    static var previews: some View {
        Bookflight(startDate: .constant(Date()), endDate: .constant(Date()))
    }
}
