import SwiftUI


struct AddNumber: View {
    @Binding var numericValue: String
    @State private var startDate = Date()
    @State private var endDate = Date()
    @State private var isShowingStartDatePicker = false
    @State private var isShowingEndDatePicker = false
    @State private var numericValue: String = ""

    
    var body: some View {
        VStack {
            Text("When do you want to go 📆?")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(Color.teal)
                .multilineTextAlignment(.trailing)
                .padding().padding().padding()
            
            VStack {
                Text("Start Date: \(formatDate(startDate))")
                    .padding()
                Button(action: {
                    isShowingStartDatePicker.toggle()
                }) {
                    HStack {
                        Text("Start Date")
                            .font(.headline)
                        
                        Spacer()
                        
                        Image(systemName: "calendar")
                            .font(.title)
                            .foregroundColor(.white)
                    }
                    .padding()
                    .background(Color.teal)
                    .foregroundColor(.white)
                    .cornerRadius(25)
                    .shadow(color: Color.blue.opacity(0.3), radius: 5, x: 0, y: 2)
                   
                }
                .sheet(isPresented: $isShowingStartDatePicker, content: {
                    DatePicker("Select Start Date", selection: $startDate, displayedComponents: .date)
                        .datePickerStyle(GraphicalDatePickerStyle())
                        .padding()
                })
                
                Text("End Date: \(formatDate(endDate))")
                    .padding()
                Button(action: {
                    isShowingEndDatePicker.toggle()
                }) {
                    HStack {
                        Text("End Date")
                            .font(.headline)
                        
                        Spacer()
                        
                        Image(systemName: "calendar")
                            .font(.title)
                            .foregroundColor(.white)
                    }
                    .padding()
                    .background(Color.teal)
                    .foregroundColor(.white)
                    .cornerRadius(25)
                    .shadow(color: Color.blue.opacity(0.3), radius: 5, x: 0, y: 2)
                }
                .sheet(isPresented: $isShowingEndDatePicker, content: {
                    DatePicker("Select End Date", selection: $endDate, in: startDate..., displayedComponents: .date)
                        .datePickerStyle(GraphicalDatePickerStyle())
                        .padding()
                })
                .onChange(of: startDate) { newStartDate in
                    // Update end date to be after the selected start date
                    if endDate < newStartDate {
                        endDate = newStartDate
                    }
                }
                
                NavigationLink {
                    Planner(startDate: $startDate, endDate: $endDate)
                } label: {
                    Text("Submit")
                        .frame(width: 120, height: 10)
                        .padding(19.0)
                        .background(Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(25)
                        .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 2)
                        .padding(.top, 50)
                }
            }
            .padding()
        }
    }
}

public func formatDate(_ date: Date) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd MMM yyyy"
    
    let formattedDate = dateFormatter.string(from: date)

    return formattedDate
}
}
            VStack {
                TextField("Enter number of group members", text: Binding(
                    get: {
                        numericValue
                    },
                    set: { newValue in
                        let filteredValue = newValue.filter { "0123456789".contains($0) }
                        if let intValue = Int(filteredValue), (1...20).contains(intValue) {
                            numericValue = filteredValue
                        } else {
                            numericValue = ""
                        }
                    }
                )
                          ,onCommit: {
                    // Code to be executed when the user presses the "Enter" button
                    // You can perform any action here if needed.
                })
                .keyboardType(.numberPad)
                
                
                NavigationLink {
                    Budget(numericValue: $numericValue)
                } label: {
                    Text("Enter")
                            .frame(width:120, height: 10)
                            .padding(19.0)
                            .background(Color.teal)
                            .foregroundColor(.white)
                            .cornerRadius(25)
                            .buttonStyle(.borderedProminent)
                            .shadow(color: .black, radius:5, x:0, y:2)
                        
                    
                }
            }
            
            
            
            
        }
    }



    
    var body: some View {
        VStack {
            Text("Step 1:")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(Color(red: 0.075, green: 0.1607843137254902, blue: 0.30980392156862746))
                .multilineTextAlignment(.leading)
                .padding(.trailing, 285.0).padding()
            
            Text("Select number of people for your trip:")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(Color(red: 0.075, green: 0.1607843137254902, blue: 0.30980392156862746))
                .multilineTextAlignment(.leading)
                .padding(.trailing, 75.0)
            
            AddNumber(numericValue: $numericValue)
                .padding()
            
            
        
    }
}




