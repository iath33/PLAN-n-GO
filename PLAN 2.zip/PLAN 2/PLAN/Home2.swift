//
//  ContentView.swift
//  PLAN
//
//  Created by Farah N on 14/01/1445 AH.
//
import SwiftUI

struct HomePage: View {

    var body: some View {

        NavigationView(){
            
                VStack(){
                    Text("PLAN n' GO")
                        .font(.title)
                        .font(.custom("Helvetica", size: 25))
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                  
                    Text("your passport to unforgettable journeys🌍!")
                        .font(.custom("Helvetica", size: 17))

                        .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                    
                    
                    HStack(spacing: 20) {
                        
                        
                        Text("Search for country")
                            .frame(width: 330)
                            .overlay(
                                Image(systemName: "magnifyingglass")
                                    .foregroundColor(.teal)
                                    .padding(.leading, 300)
                                    .frame(width: 11.0, height: 7.0)
                                 )
                            .font(.custom("Helvetica", size: 14))
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.leading)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                        
                        
                    }
                    
        .padding()
                    
                    Text("Explore")
                        .font(.custom("Helvetica", size: 17))

                        .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                    
                    
                    HStack{
                        
                        NavigationLink {
                            AddDateCalender()
                                .navigationTitle("plan n' go ")

                        } label: {
                            Image("Italy")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .scaledToFit()
                            .cornerRadius(10)
                        
                            .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                        
                                .overlay(
                                    Text("         Italy")
                                        .font(.custom("Helvetica", size:26
                                                     ) .bold())
                                        .foregroundColor(.white)
                                        .padding(.top, 120.0)
                                        .shadow(color: Color.black.opacity(1), radius: 1, x: 3, y: 5)
                                )
                        
                        }

           
                        
                        Button {
                            
                        } label: {
                            Image("USA")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .scaledToFit()
                                .cornerRadius(10)
                            
                                .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                            
                                .overlay(
                                    Text("          USA")
                                        .font(.custom("Helvetica", size:26
                                                     ) .bold())
                                        .foregroundColor(.white)
                                        .padding(.top, 120.0)
                                        .shadow(color: Color.black.opacity(1), radius: 1, x: 3, y: 5)

                                )
                            
                        }
                        
                        
                        
                    }
                    
                    //
                    VStack{
                        HStack{
                            Button {
                                
                            } label: {
                                Image("canada")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .scaledToFit()
                                    .cornerRadius(10)
                                
                                    .shadow(color: Color.black.opacity(0), radius: 0, x: 0, y: 0)
                            
                                    .overlay(
                                        Text("    Canada")
                                            .font(.custom("Helvetica", size:26
                                                         ) .bold())
                                            .foregroundColor(.white)
                                            .padding(.top, 120.0))
                                    .shadow(color: Color.black.opacity(1), radius: 1, x: 3, y: 5)

                                
                            }
                            Button {
                                
                            } label: {
                                Image("UK")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .scaledToFit()
                                    .cornerRadius(10)
                                
                                    .shadow(color: Color.black.opacity(0), radius: 0, x: 0, y: 0)

                                    .overlay(
                                        Text("            UK")
                                            .font(.custom("Helvetica", size:26
                                                         ) .bold())
                                            .foregroundColor(.white)
                                            .padding(.top, 120.0))
                                    .shadow(color: Color.black.opacity(1), radius: 1, x: 3, y: 5)

                                
                            }
                            
                        }
                        
                    }
    
                }.padding(.horizontal)
                
            
        }
        
    }
    
    @main
    struct MuseumApp: App {
        var body: some Scene {
            WindowGroup {
                SplashScreen2()
            }
        }
    }


    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            HomePage()
        }
    }
}
