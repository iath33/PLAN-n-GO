import SwiftUI

struct AddDateCalender: View {
    @State private var startDate = Date()
        @State private var endDate = Date()
        @State private var isShowingStartDatePicker = false
        @State private var isShowingEndDatePicker = false
        @State private var numericValue: String = ""
        
        var body: some View {
            ScrollView {
                VStack {
                 
                    
                    Text("Start planning your trip! ")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.075, green: 0.1607843137254902, blue: 0.30980392156862746))
                        .multilineTextAlignment(.leading)
                        .padding(.trailing,12)
     
                    Text("How many travellers 👥?")
                        .padding(.top, 40)
                        .padding(.trailing, 150)
                        .fontWeight(.bold)
                 
                    
                    TextField("Enter number btween 1-20", text: Binding(
                                  get: {
                                      numericValue
                                  },
                                  set: { newValue in
                                      let filteredValue = newValue.filter { "0123456789".contains($0) }
                                      if let intValue = Int(filteredValue), (1...20).contains(intValue) {
                                          numericValue = filteredValue
                                      } else {
                                          numericValue = ""
                                      }
                                  }
                              )
                                        ,onCommit: {
                                  // Code to be executed when the user presses the "Enter" button
                                  // You can perform any action here if needed.
                              })
                              .keyboardType(.numberPad)
                              

                              .padding()
               
            
                    
                    Spacer() // Add a spacer to push content to the top

                    Divider()
                        .padding(.bottom,50)

                    
                    Text("When do you want to go 📆?")
                    //padding(.top, 20)
                        .padding(.trailing, 112.0)
                        .padding(.bottom,30)
                        .fontWeight(.bold)
                        
                    
                    VStack {
            
                        Button(action: {
                            isShowingStartDatePicker.toggle()
                        }) {
                            HStack {
                                Text("Start Date")
                                    .font(.headline)
                                
                                Spacer()
                                
                                Image(systemName: "calendar")
                                    .font(.title)
                                    .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                            }
                            .padding()
                            .background(Color.white)
                            .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                            .cornerRadius(25)
                            .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 2)
                        }
                        Text("Start Date: \(formatDate(startDate))")
                            .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                            .padding()
                        .sheet(isPresented: $isShowingStartDatePicker, content: {
                            VStack {
                                HStack {
                                    Spacer()
                                    Button("Done") {
                                        isShowingStartDatePicker.toggle()
                                    }
                                    .padding(.trailing)
                                }
                                DatePicker("Select Start Date", selection: $startDate, displayedComponents: .date)
                                    .datePickerStyle(GraphicalDatePickerStyle())
                                    .padding()
                            }
                        })
                        
                        Button(action: {
                            isShowingEndDatePicker.toggle()
                        }) {
                            HStack {
                                Text("End Date")
                                    .font(.headline)
                                
                                Spacer()
                                
                                Image(systemName: "calendar")
                                    .font(.title)
                                    .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                            }
                            .padding()
                            .background(Color.white)
                            .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                            .cornerRadius(25)
                            .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 2)
                        }
                        Text("End Date: \(formatDate(endDate))")
                            .foregroundColor(Color(red: 0.122, green: 0.286, blue: 0.576))
                            .padding()
                        .sheet(isPresented: $isShowingEndDatePicker, content: {
                            VStack {
                                HStack {
                                    Spacer()
                                    Button("Done") {
                                        isShowingEndDatePicker.toggle()
                                    }
                                    .padding(.trailing)
                                }
                                DatePicker("Select End Date", selection: $endDate, in: startDate..., displayedComponents: .date)
                                    .datePickerStyle(GraphicalDatePickerStyle())
                                    .padding()
                            }
                        })
                        .onChange(of: startDate) { newStartDate in
                            // Update end date to be after the selected start date
                            if endDate < newStartDate {
                                endDate = newStartDate
                            }
                        }
                        
                    
                    
                    NavigationLink {
                        Budget(startDate:$startDate, endDate: $endDate, numericValue: $numericValue)
                    } label: {
                        Text("Submit")
                            .font(.headline)
                            .frame(width: 250, height: 20)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color(red: 0.122, green: 0.286, blue: 0.576))
                            .cornerRadius(10)
                            
                    }
                }
                .padding()
            }
        }
    }
    public func formatDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        
        let formattedDate = dateFormatter.string(from: date)
        
        return formattedDate
    }
    
    
    
    
    struct AddDateCalender_Previews: PreviewProvider {
        static var previews: some View {
            AddDateCalender()
        }
    }
}
