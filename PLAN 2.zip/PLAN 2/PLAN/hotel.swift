//
//  hotel.swift
//  PLAN
//
//  Created by Atheer Alharbi on 13/08/2023.
//
import SwiftUI

struct hotel: View {
    var body: some View {
        ScrollView{
            VStack{
                Text("Book a hotel 🏨")
                    .font(.title2)
                    .bold()
                    .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                    .padding(.trailing, 160)
                    .padding()
                
                Rectangle()
                    .frame(width: 350, height: 100)
                    .foregroundColor((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                    .overlay(
                        Text("David hotel")
                            .font(.title3)
                            .bold()
                            .padding(.bottom, 50)
                            .padding(.trailing, 200)
                            .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                            .padding()
                            .padding(.top, 19.0)
                        
                    ) .overlay(
                        Image("d")
                            .resizable()
                            .frame(width: 130, height: 100)
                            .cornerRadius(10)
                            .padding(.leading, 219)
                        
                        
                    )
                    .overlay(Text("Florence")
                        .padding(.top, 30)
                        .padding(.trailing, 240)
                        .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                    )
                
                Rectangle()
                    .frame(width: 350, height: 100)
                    .foregroundColor((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                    .overlay(
                        Text("Antiche Figure")
                            .font(.title3)
                            .bold()
                            .padding(.bottom, 50)
                            .padding(.trailing, 170)
                            .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                            .padding()
                            .padding(.top, 19.0)
                    )
                    .overlay(
                        Image("v")
                            .resizable()
                            .frame(width: 130, height: 100)
                            .cornerRadius(10)
                            .padding(.leading, 219)
                    )
                    .overlay(Text("Venice")
                        .padding(.top, 40)
                        .padding(.trailing, 255)
                        .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                    )
                    .padding()
                Rectangle()
                    .frame(width: 350, height: 100)
                    .foregroundColor((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                    .overlay(
                        Text("Artemide")
                            .font(.title3)
                            .bold()
                            .padding(.bottom, 50)
                            .padding(.trailing,218)
                            .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                            .padding()
                            .padding(.top, 19.0)
                    )
                    .overlay(
                        Image("a")
                            .resizable()
                            .frame(width: 130, height: 100)
                            .cornerRadius(10)
                            .padding(.leading, 219)
                        
                        
                    )
                    .overlay(Text("Rome")
                        .padding(.top, 40)
                        .padding(.trailing, 260)
                        .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
                    )
                
                
            }
            
        }
        }
    
}
struct hotel_Previews: PreviewProvider {
    static var previews: some View {

        hotel()
            }
}
