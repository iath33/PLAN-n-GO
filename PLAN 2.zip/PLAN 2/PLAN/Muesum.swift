import SwiftUI

struct Artifact: Identifiable {
    let id = UUID()
    let name: String
    let description1: String
    let country: String
    let description2: String
    let imageName: String
}

struct MuseumView: View {
@State private var Museum: [Artifact] = []
    @Binding var startDate : Date
    @Binding var endDate : Date
    
    let artifacts: [Artifact] = [
        Artifact(name: "The Uffizi Gallery",  description1: "", country: "Florance", description2: "The Gallery entirely occupies the first and second floors of the large building constructed between 1560 and 1580 and designed by Giorgio Vasari. ", imageName: "M1"),
        Artifact(name: "Bargello National Museum", description1: "", country: "Florance", description2: "It features Renaissance masterpieces, decorative arts, and medieval artifacts, all within a unique architectural setting.", imageName: "m2"),
        Artifact(name: "The Pinacoteca di Brera.", description1: "", country: "Milan", description2: "The Pinacoteca di Brera is a famous art gallery in Milan, Italy, known for its exceptional collection of Italian Renaissance, Baroque, and Neoclassical paintings.", imageName: "m3"),
        Artifact(name: "Castel Sant'Angelo", description1: "", country: "Rome", description2: "Castel Sant'Angelo, located in Rome, Italy, is a historic fortress that has served as a mausoleum, castle, and papal residence.",imageName: "m4"),
    ]
    
    var body: some View {

        Text("Museum")
            .font(.title2)
            .bold()
            .foregroundColor(Color(red: 0.10196078431372549, green: 0.2549019607843137, blue: 0.5176470588235295))
            .padding(.trailing, 190)
      
            List(artifacts) { artifact in
                NavigationLink(destination: ArtifactDetailView(artifact: artifact, Museum: $Museum, startDate:$startDate, endDate: $endDate )) {
                    VStack(alignment: .leading) {
                        Text(artifact.name)
                            .font(.headline)
                            .foregroundColor(Color(hue: 0.606, saturation: 0.787, brightness: 0.577))
                            .bold()

                        
                        Text(artifact.description1)
                            .font(.subheadline)
                            .font(.custom("Helvetica", size: 14))
                            .foregroundColor(.secondary)
                        
                        Text("City:")
                            .font(.custom("Helvetica", size: 14))
                            .foregroundColor(Color(hue: 0.606, saturation: 0.787, brightness: 0.577))
                            .bold()

                        
                        Text(artifact.country)
                            .font(.custom("Helvetica", size: 14))
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                               }
                               
                               }
            
    
                               }
                               
                    

struct ArtifactDetailView: View {
    let artifact: Artifact
    @State private var currentIndex = 0
    @Binding var Museum: [Artifact]
    @Binding var startDate : Date
    @Binding var endDate : Date
    
    var body: some View {
            ScrollView{
                
                
                VStack {
                    Text(artifact.name)
                        .font(.title)
                        .padding()
                        .bold()
                        .foregroundColor(Color(hue: 0.606, saturation: 0.787, brightness: 0.577))
                    
                    Image(artifact.imageName) // Display image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(10)
                        .frame(width: 300, height: 300)
                        .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                    
                    
                    
                    Text(artifact.description2)
                        .font(.body)
                        .padding(.leading, 15.0)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .multilineTextAlignment(.leading)
                        .lineSpacing(5) // Adjust as needed
                        .padding(.horizontal)
                        .foregroundColor(.secondary)
                        .padding()
                    HStack{
                        Image(systemName: "location")
                            .foregroundColor(Color(hue: 0.606, saturation: 0.787, brightness: 0.577))
                        
                        Text(artifact.country)
                            .foregroundColor(Color(hue: 0.606, saturation: 0.787, brightness: 0.577))
                        
                        
                        
                    }
                    .padding()
                    Button(action: {
                        Museum.append(artifact)
                        print(Museum)
                    }) {
                        Text("Add to my schedule")
                            .font(.headline)
                            .frame(width: 250, height: 20)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color(red: 0.122, green: 0.286, blue: 0.576))
                            .cornerRadius(10)
                    }
                    
                    Spacer()
                }
                NavigationLink(destination: Schedule(Museum: $Museum, startDate:$startDate, endDate: $endDate)) {
                    Text("View my schedule")
                        .font(.headline)
                        .frame(width: 250, height: 20)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color(red: 0.122, green: 0.286, blue: 0.576))
                        .cornerRadius(10)
                }
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarTitle(artifact.name)
            }
            
        }
        
        
    }
