//
//  PLANNER.swift
//  PLAN
//
//  Created by Farah N on 15/01/1445 AH.
//
import SwiftUI

struct Planner: View {
    @Binding var startDate : Date
    @Binding var endDate : Date
    var body: some View {
            ScrollView{
                VStack{
                
                    Text("What can we help you with🤔?")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color(red: 0.075, green: 0.1607843137254902, blue: 0.30980392156862746))
                        .multilineTextAlignment(.trailing)
                        .padding(.trailing, 40.0)
                    
                    
                    
                    NavigationLink{
                        Bookflight(startDate: $startDate, endDate: $endDate)
                    }label: {
                        Text("Book a flight ✈️")
                            .font(.custom("Helvetica", size: 18))
                                        .frame(width: 270, height: 80)
                                        .fontWeight(.bold)
                                        .foregroundColor(Color(red: 0.075, green: 0.1607843137254902, blue: 0.30980392156862746))
                                        .multilineTextAlignment(.leading)
                                        .padding()
                                        .background((Color(red: 0.949, green: 0.949, blue: 0.949))) // Change background color to gray
                                        .cornerRadius(20)
                                        .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                                        .padding()
                        
                        
                    }
                    
                    
                    
                    
                    NavigationLink{
                      hotel()
                        
                  
                    } label: {
                        Text("Reserve a hotel🏨")
                            .font(.custom("Helvetica", size: 18))
                                             .frame(width: 270, height: 80)
                                             .fontWeight(.bold)
                                             .foregroundColor(Color(red: 0.075, green: 0.1607843137254902, blue: 0.30980392156862746))
                                             .multilineTextAlignment(.leading)
                                             .padding()
                                             .background((Color(red: 0.949, green: 0.949, blue: 0.949))) // Change background color to gray
                                             .cornerRadius(20)
                                             .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                                             .padding()

                        
                    }
                    
                    
             
                    
                    NavigationLink{
                        SwiftUIView(startDate: $startDate, endDate: $endDate)
                        
                    }label: {
                        Text("Schedule activites🏄🏻‍♂️ ")
                            .font(.custom("Helvetica", size: 18))
                                             .frame(width: 270, height: 80)
                                             .fontWeight(.bold)
                                             .foregroundColor(Color(red: 0.075, green: 0.1607843137254902, blue: 0.30980392156862746))
                                             .multilineTextAlignment(.leading)
                                             .padding()
                                             .background((Color(red: 0.949, green: 0.949, blue: 0.949))) // Change background color to gray
                                             .cornerRadius(20)
                                             .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                                             .padding()

                    }
                    
               
                    
                    
       
                        Text("Restaurants/Cafe🍴☕️")
                        .font(.custom("Helvetica", size: 18))
                                         .frame(width: 270, height: 80)
                                         .fontWeight(.bold)
                                         .foregroundColor(Color(red: 0.075, green: 0.1607843137254902, blue: 0.30980392156862746))
                                         .multilineTextAlignment(.leading)
                                         .padding()
                                         .background((Color(red: 0.949, green: 0.949, blue: 0.949))) // Change background color to gray
                                         .cornerRadius(20)
                                         .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                                         .padding()

                        
                    }
                }
            }
        }
    

//struct PLANNER_Previews: PreviewProvider {
//    static var previews: some View {
  //      ContentView3(startDate: $startDate, endDate: $endDate)
    //}
//}
