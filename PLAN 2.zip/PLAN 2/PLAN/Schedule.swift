//
//  Schedule.swift
//  Last
//  Created by Farah N on 26/01/1445 AH.
//

import SwiftUI

struct Schedule: View {
    @Binding var Museum: [Artifact]
    @Binding var startDate : Date
    @Binding var endDate : Date
    
    var body: some View {
        VStack {
            Text("The places you can visit From \(formatDate2(startDate)) to \(formatDate2(endDate)) 🌍")
                .font(.custom("Helvetica", size: 17))
            
                .font(.title2)
                .bold()
                .foregroundColor(Color(hue: 0.606, saturation: 0.787, brightness: 0.577))
            
            List(Museum) { Artifact in
                VStack(alignment: .center) {
                    Text(Artifact.name)
                        .font(.title2)
                        .bold()
                        .foregroundColor(Color(hue: 0.606, saturation: 0.787, brightness: 0.577))
                    
                    Image(Artifact.imageName) // Display image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(10)
                        .frame(width: 300, height: 300)
                        .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)

                                
             
                    Text(Artifact.description1)
                        .font(.body)
                        .padding(.leading, 15.0)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .multilineTextAlignment(.leading)
                        .lineSpacing(5) // Adjust as needed
                        .padding(.horizontal)
                        .foregroundColor(.secondary)
                        .padding()
                    HStack{
                        Image(systemName: "location")
                            .foregroundColor(Color(hue: 0.606, saturation: 0.787, brightness: 0.577))
                        
                        Text(Artifact.country)
                            .foregroundColor(Color(hue: 0.606, saturation: 0.787, brightness: 0.577))
                          
                        
                        
                    }
                    
                    Spacer()
                    
                }
            }
        }.onAppear(){
            print(Museum)
        }
    }
}
public func formatDate2(_ date: Date) -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "dd MMM yyyy" // Custom date format
    
    let formattedDate = dateFormatter.string(from: date)

    return formattedDate
}
