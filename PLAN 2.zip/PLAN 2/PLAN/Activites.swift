//
//  SwiftUIView.swift
//  plan n go
//
//  Created by reyoof h on 15/01/1445 AH.
//

import SwiftUI

struct SwiftUIView: View {
    @Binding  var startDate : Date
    @Binding  var endDate : Date
    var body: some View {
        ScrollView{
            VStack{
                Text("Experiences you don’t want to miss !").bold().frame(maxWidth: .infinity, alignment: .leading)
                    .font(.system(size: 22))
                    .padding(.leading, 10)
                    .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                
                NavigationLink {
                    MuseumView(startDate: $startDate, endDate: $endDate)
                     
                } label: {
                    Text("Art & Museum").bold()
                        .padding(.bottom, 30.0)
                        .frame(width: 260, height: 110)
                        .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                        .background(Color(red: 0.949, green: 0.949, blue: 0.949))
                        .cornerRadius(20)
                        .shadow(color: Color.black.opacity(0.5),radius: 4, x:0, y:2)
                        .font(.system(size: 25))
                        .padding()
                        .overlay(
                            // Image(systemName:"building.columns.fill")
                            Text("🏛️").bold()
                                .font(.system(size:30))
                                .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                                .padding(.top,50.0))
                }

                
                
                
                Text("Nature & Wildlife").bold()
                    .padding(.bottom, 40.0)
                    .frame(width: 260, height: 110)
                    .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                    .background((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5),radius: 4, x:0, y:2)
                    .font(.system(size: 25))
                    .padding()
                    .overlay( //Image(systemName:"leaf.fill")
                        Text("🍀").bold()
                            .font(.system(size:30))
                            .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                            .padding(.top,50.0))
                
                
                Text("Shopping").bold()
                    .padding(.bottom, 40.0)
                    .frame(width: 260, height: 110)
                    .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                    .background((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5),radius: 4, x:0, y:2)
                    .font(.system(size: 25))
                    .padding()
                    .overlay(
                        Text("🛍️").bold()
                        // Image(systemName:"cart")
                            .font(.system(size:30))
                            .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                            .padding(.top,50.0))
                
                
                
                Text("Parks").bold()
                    .padding(.bottom, 40.0)
                    .frame(width: 260, height: 110)
                    .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                    .background((Color(red: 0.949, green: 0.949, blue: 0.949)))
                    .cornerRadius(20)
                    .shadow(color: Color.black.opacity(0.5),radius: 4, x:0, y:2)
                    .font(.system(size: 25))
                    .padding()
                    .overlay(
                        Text("🚲").bold()
                        // Image(systemName:"bicycle")
                            .font(.system(size:30))
                            .foregroundColor(Color(red: 0.07450980392156863, green: 0.1607843137254902, blue: 0.30980392156862746))
                            .padding(.top,30.0))
                
                
                
            }}
        
    }
}
