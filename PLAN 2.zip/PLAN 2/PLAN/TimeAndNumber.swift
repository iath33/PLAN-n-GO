//
//  TimeAndNumber.swift
//  PLAN
//
//  Created by Atheer Alharbi on 09/08/2023.
//

import SwiftUI

struct TimeAndNumber: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct TimeAndNumber_Previews: PreviewProvider {
    static var previews: some View {
        TimeAndNumber()
    }
}
